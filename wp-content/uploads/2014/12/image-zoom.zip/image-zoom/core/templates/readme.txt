=== My Plugin ===

Contributors: Your name
Author: Your name
Author URI: http://www.yourdomain.com
Plugin URI: http://wordpress.org/extend/plugins/my-plugin/
Tags: plugin
Requires at least: 3.0
Tested up to: 3.2
Stable tag: trunk

The short description

== Description ==

The long description

== Installation ==

1. Upload this folder to your plugin directory (for instance '/wp-content/plugins/')
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Navigate to the 'SL plugins' box
4. All plugins developed with the SL core will be listed in this box
5. Enjoy !

== Screenshots ==


== Changelog ==


== Frequently Asked Questions ==


